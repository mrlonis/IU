# MIPS simulator

## Compiling

In the src directory, run
```
javac -d .. procsimu/*.java
```

## Running

In the project root directory, run
```
java procsimu.Control
```
